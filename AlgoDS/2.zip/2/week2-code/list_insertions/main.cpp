#include "linked_list.h"
#include <iostream>

int main() {
  /* TODO:
      Write a program that reads a singly linked list of strings from standard
     input, followed by a string to insert into the list. The program should
     insert the string into the list such that the list remains sorted in
     alphabetic order. The program should print the updated list to standard
     output.


      Example input: [apple -> banana -> cherry] blueberry
      Example output: [apple -> banana -> blueberry -> cherry]
  */
  sax::linked_list_node<std::string> *head = nullptr;
  std::cin >> head;
  std::string element;
  if (!std::cin) {
    std::cerr << "Failed to read list from input." << std::endl;

    // in case some memory was allocated before the failure, we need to clean it
    // up the cleanup function can handle a nullptr input, so it's safe to call
    // even if head is still nullptr
    sax::linked_list_node<std::string>::cleanup(head);
    return 1;
  }

  // if the list is empty, the head pointer will be nullptr
  if (head == nullptr) {
    std::cout << "[]" << std::endl; // Empty list
    return 0;
  }
  std::cin >> element;
  auto *new_node = new sax::linked_list_node<std::string>{element};

  sax::linked_list_node<std::string> *current = head;
  while (current->next != nullptr && current->next->data < element) {
    current = current->next;
  }
  new_node->next = current->next;
  current->next = new_node;
  std::cout << head << std::endl;

  // Clean up
  sax::linked_list_node<std::string>::cleanup(head);
  return 0;
}
