#include <iostream>
#include "utils.h"

int main() {
    /* TODO:
        Write a program that reads a vector of integers from standard input,
        followed by a number N. The program should find a contiguous (i.e. without gaps) subvector
        of the input vector that sums to N.
        If such a subvector is found, the program should print it.
        If no such subvector exists, the program should print an empty vector ("[]").

        Example input: [1, 2, 3, 4, 5] 9
        Example output: [2, 3, 4]
    */
    return 0;
}
