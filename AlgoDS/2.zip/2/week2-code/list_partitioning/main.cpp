#include <iostream>
#include "linked_list.h"

int main() {
    /* TODO:
        Write a program that reads a singly linked list of strings from standard input,
        followed two antegers i and n. The program should move the first n nodes starting from index i (index 0 is the first node)
        to the front of the list. The program should print the updated list to standard output. 

        Example input: [apple -> banana -> cherry] 1 2
        Example output: [banana -> cherry -> apple]
    */
    return 0;
}
