#include "linked_list.h"
#include <iostream>

int main() {
  /* TODO:
      Write a program that reads two singly linked lists of integers from
     standard input. The program should build a new list that forms the union of
     the two input lists, by rearranging the nodes of the input lists (i.e., do
     not create new nodes).

      The input lists are sorted in ascending order and do not contain
     duplicates. The output list should also be sorted in ascending order and
     should not contain duplicates.

      The program should print the resulting list to standard output.

      Example input: [1 -> 2 -> 3] [2 -> 3 -> 4]
      Example output: [1 -> 2 -> 3 -> 4]


  */
  return 0;
}
