
#include <iostream>
#include <string>

int main() {
    size_t size;
    std::cin >> size;
    std::cin.ignore(); 

    char* buffer = new char[size]{};

    size_t head = 0;  
    size_t tail = 0;  
    size_t count = 0; 

    char ch;
    while (std::cin.get(ch)) {
        if (ch == '*') {
            
            if (count > 0) {
                std::cout << buffer[head];
                head = (head + 1) % size;
                --count;
            }
        } else {
            
            buffer[tail] = ch;
            tail = (tail + 1) % size;
            if (count < size) {
                ++count;
            } else {
                
                head = (head + 1) % size;
            }
        }
    }

    delete[] buffer;
    return 0;
}
