#include <iostream>
#include <string>
#include <array>

int main() {
  /* TODO:
      Write a program that reads two lines of input: the first line contains a word,
      and the second line contains a sentence that may contain an anagram of the word (ignoring spaces).
      The program should find the first anagram of the word in the sentence and print it.
      If no anagram is found, the program should print "<not found>".

      Example input:
        conversation
        our voices rant on forever
      Example output: voices rant on
  */
  return 0;
}
